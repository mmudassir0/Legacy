export const studentsGroups = [
  "TypoGraphy",
  "Biologist",
  "Chemistry",
  "Web Designer",
  "Black Magicians",
  "Lame Gamer Boy",
];
