import React from "react";
import axios from "axios";
import { User } from "../components/Interface";

const usePost = (url: string) => {
  const [data, setData] = React.useState<User>();
  const [loading, setLoading] = React.useState(false);
  const makeRequest = (requestData: User) => {
    setLoading(true);
    axios
      .post(url, requestData)
      .then((res) => {
        setLoading(false);
        setData(res.data.student);
      })
      .catch((error) => {
        console.log("Error in post data" + error.message);
      });
  };

  return { data, loading, makeRequest };
};

export default usePost;
