import React from "react";
import {
  Checkbox,
  Container,
  FormControlLabel,
  FormGroup,
  FormLabel,
} from "@mui/material";
import { studentsGroups } from "../util/constants/StudentsGroups";
import { User } from "./Interface";

type FilterGroupsProps = {
  tableData: User[];
  orignalTableData: User[];
  isSearching: boolean;
  setTableData: React.Dispatch<React.SetStateAction<User[]>>;
  setIsGroupFiltering: React.Dispatch<React.SetStateAction<boolean>>;
};

const FilterGroups = ({
  tableData,
  setTableData,
  orignalTableData,
  setIsGroupFiltering,
  isSearching,
}: FilterGroupsProps) => {
  const [selectedGroups, setSelectedGroups] = React.useState<string[]>([]);

  const handleCheckboxChange = (option: string) => {
    const isSelected = selectedGroups.includes(option);

    if (isSelected) {
      setSelectedGroups(selectedGroups.filter((group) => group !== option));
    } else {
      setSelectedGroups([...selectedGroups, option]);
    }
  };

  React.useEffect(() => {
    if (selectedGroups.length === 0 && !isSearching) {
      setTableData(orignalTableData);
      setIsGroupFiltering(false);
    } else if (isSearching) {
      const filteredData = tableData.filter((item) =>
        selectedGroups.some((group) => item.groups.includes(group))
      );
      setTableData(filteredData);
      setIsGroupFiltering(true);
    } else if (!isSearching) {
      const filteredData = orignalTableData.filter((item) =>
        selectedGroups.some((group) => item.groups.includes(group))
      );
      console.log(filteredData);
      setTableData(filteredData);
      setIsGroupFiltering(true);
    }
  }, [selectedGroups]);

  return (
    <Container>
      <FormGroup>
        <FormLabel>Filter for Study Groups</FormLabel>
        {studentsGroups.map((group) => {
          return (
            <FormControlLabel
              key={group}
              control={
                <Checkbox
                  checked={selectedGroups.includes(group)}
                  onChange={() => handleCheckboxChange(group)}
                />
              }
              label={group}
            />
          );
        })}
      </FormGroup>
    </Container>
  );
};

export default FilterGroups;
