import React from "react";
import {
  Container,
  InputAdornment,
  TextField,
  Typography,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import { User } from "./Interface";

type FilterSearchProps = {
  tableData: User[];
  orignalTableData: User[];
  isGroupFiltering: boolean;
  setTableData: React.Dispatch<React.SetStateAction<User[]>>;
  setIsSearching: React.Dispatch<React.SetStateAction<boolean>>;
};
const FilterWithSearch = ({
  tableData,
  setTableData,
  orignalTableData,
  setIsSearching,
  isGroupFiltering,
}: FilterSearchProps) => {
  const [search, setSearch] = React.useState("");
  const [issearch, setIsSearch] = React.useState(false);

  const handleSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
    const searchName = event.target.value;
    setSearch(searchName);
  };

  console.log(search, "search");

  console.log(search ? true : false, "searchhhhhhhhhhhhhhhh", issearch);

  React.useEffect(() => {
    if (search) {
      setIsSearch(true);
    } else {
      setIsSearch(false);
    }
    if (search && !isGroupFiltering) {
      let filterData = orignalTableData.filter((item) =>
        item.name.toLowerCase().includes(search.toLowerCase())
      );
      setTableData(filterData);
      setIsSearching(true);

      // setSearchFilter(filterData);
    } else if (isGroupFiltering) {
      let groupFilterData = tableData.filter((item) =>
        item.name.toLowerCase().includes(search.toLowerCase())
      );
      setTableData(groupFilterData);
      setIsSearching(true);
    } else if (!search) {
      setTableData(orignalTableData);
      setIsSearching(false);
    }

    // console.log(filterData, "filterData filterData filterData ");
  }, [search]);
  // const filteredTableData = search
  //   ? tableData.filter((item) =>
  //       item.name.toLowerCase().includes(search.toLowerCase())
  //     )
  //   : tableData;

  //   setTableSearchWithName(filteredTableData);
  // console.log(filteredTableData, "filteredTableData filteredTableData");
  // console.log(tableData, "tableData");
  //   updateTableData(searchByName);

  const filterdData = tableData.filter((item) =>
    item.name.toLowerCase().includes(search.toLowerCase())
  );
  console.log(filterdData, "filterdData filterdData filterdData ");
  return (
    <Container>
      <Typography variant="subtitle2" marginBottom={1}>
        SEARCH FOR NAME
      </Typography>

      <TextField
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon />
            </InputAdornment>
          ),
        }}
        variant="filled"
        placeholder="Search"
        size="small"
        hiddenLabel
        onChange={handleSearch}
      />
    </Container>
  );
};

export default FilterWithSearch;
