import React from "react";

import { User } from "./Interface";
import TableData from "./Tabledata";
import FormsButton from "./FormsButton";
import { Container, Divider, Grid } from "@mui/material";
import FilterWithSearch from "./FilterWithSearch";
import FilterGroups from "./FilterGroups";
// import useFetch from "../hooks/useFetch";

function UserData() {
  const [tableData, setTableData] = React.useState<User[]>([]);
  const [open, setOpen] = React.useState(false);
  const [isUpdating, setIsUpdating] = React.useState(false);
  const [orignalTableData, setOrignalTableData] = React.useState<User[]>([]);
  const [formData, setFormData] = React.useState<User>({
    name: "",
    place: "",
    gender: "",
    age: "",
    groups: [],
  });
  const [isSearching, setIsSearching] = React.useState(false);
  const [isGroupFiltering, setIsGroupFiltering] = React.useState(false);
  // console.log(tableData, "tableData from  userdata");
  // console.log(orignalTableData, "orignalTableData");
  console.log(isSearching, "isSearching", isGroupFiltering, "isGroupFiltering");
  return (
    <div>
      <Grid container paddingBottom={2}>
        <Grid item xs={3} padding={3}>
          <FilterWithSearch
            tableData={tableData}
            setTableData={setTableData}
            orignalTableData={orignalTableData}
            setIsSearching={setIsSearching}
            isGroupFiltering={isGroupFiltering}
          />
        </Grid>
        <Grid item xs={9} paddingTop={6}>
          <FormsButton
            tableData={tableData}
            open={open}
            setOpen={setOpen}
            formData={formData}
            setFormData={setFormData}
            isUpdating={isUpdating}
            setTableData={setTableData}
          />
        </Grid>
      </Grid>
      <Divider />
      <Grid container>
        <Grid item xs={3} padding={3}>
          <FilterGroups
            tableData={tableData}
            setTableData={setTableData}
            orignalTableData={orignalTableData}
            setIsGroupFiltering={setIsGroupFiltering}
            isSearching={isSearching}
          />
        </Grid>
        <Grid item xs={9}>
          <Container>
            <TableData
              formData={formData}
              tableData={tableData}
              setTableData={setTableData}
              setOpen={setOpen}
              setFormData={setFormData}
              setIsUpdating={setIsUpdating}
              setOrignalTableData={setOrignalTableData}
            />
          </Container>
        </Grid>
      </Grid>
    </div>
  );
}

export default UserData;
