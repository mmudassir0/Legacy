import React from "react";
import UserData from "./components/UserData";

const App: React.FC = () => {
  return (
    <div>
      <UserData />
    </div>
  );
};

export default App;
